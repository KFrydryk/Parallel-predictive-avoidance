function [u] = applyObstackleForces(in)
%APPLYOBSTACKLEFORCES Summary of this function goes here
%   Detailed explanation goes here
global obstackles
obstackles
u = in(1:2);

end

