function [u] = applyVectorField(in)
q = in(1:3);
q_p = in(4:6);
u = [0;10];

end

