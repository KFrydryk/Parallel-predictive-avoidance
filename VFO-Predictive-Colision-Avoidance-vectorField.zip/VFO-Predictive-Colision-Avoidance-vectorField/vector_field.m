x = zeros(100)
y = 10.*ones(100)
quiver(x, y)